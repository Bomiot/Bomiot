import toml
from os.path import join
from django.conf import settings


def permission_message_return(language: str, data: str) -> str:
    with open(join(settings.LANGUAGE_DIR, language + '.toml'), 'r', encoding='utf-8') as message:
        message_data = toml.load(message)
    return message_data['permission'][data]

def detail_message_return(language: str, data: str) -> str:
    print(settings.LANGUAGE_DIR)
    return 'True'

def msg_message_return(language: str, data: str) -> dict:
    print(settings.LANGUAGE_DIR)
    return {'msg': 'True'}
