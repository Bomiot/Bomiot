VERSION = (0, 1, '30')

__version__ = '.'.join(map(str, VERSION))


def version(): return __version__
