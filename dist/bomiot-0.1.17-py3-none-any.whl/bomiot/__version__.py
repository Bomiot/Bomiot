VERSION = (0, 1, '17')

__version__ = '.'.join(map(str, VERSION))


def version(): return __version__
