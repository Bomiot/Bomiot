
ADMINS = [
    'admin'
]
